# I2C Adafruit ADXL343 Example

We took the ESP32 I2C example and reworked it to control the Adafruit ADXL343 accelerometer.
