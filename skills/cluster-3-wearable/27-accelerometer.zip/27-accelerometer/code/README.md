# Code Readme

Brief explanation on how to navigate your code folder. For example, main consists of the entry function, and lib are where the resource libraries are located.
